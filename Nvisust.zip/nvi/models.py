from django.db import models

# Create your models here.
class Blog(models.Model):
    title=models.TextField(max_length=300)
    image=models.ImageField(upload_to="pics")
    description=models.TextField()
    date=models.DateTimeField()

    class Meta:
        ordering=('title',)
        verbose_name='Blog'
        verbose_name_plural= 'Blogs'
    def __str__(self):
        return '{}'.format(self.title)


class Team(models.Model):
    name=models.CharField(max_length=150)
    image=models.ImageField(upload_to="pics")
    position=models.CharField(max_length=150)
    description= models.TextField(default='No description available')

    class Meta:
        ordering=('name',)
        verbose_name='Team'
        verbose_name_plural= 'Teams'
    def __str__(self):
        return '{}'.format(self.name)

class Gallery(models.Model):
    event=models.CharField(max_length=150)
    image=models.ImageField(upload_to="pics")

    class Meta:
        ordering=('event',)
        verbose_name='Gallery'
        verbose_name_plural= 'Gallery'
    def __str__(self):
        return '{}'.format(self.event)

class Project(models.Model):
    name=models.CharField(max_length=150)
    image=models.ImageField(upload_to="pics")
    description=models.TextField(default='No description available')

    class Meta:
        ordering=('name',)
        verbose_name='Project'
        verbose_name_plural= 'Projects'
    def __str__(self):
        return '{}'.format(self.name)


