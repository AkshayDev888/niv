from nvi import views
from django.urls import path
app_name='nvi'

urlpatterns=[
    path('',views.Home,name='Home'),
    path('krish/',views.Team1,name='Team1'),
    path('mithun/',views.Team2,name='Team2'),
    path('raj/',views.Team3,name='Team3'),
    path('blog/<int:id>/',views.Blog_detail,name='Blog_detail'),

]

# path('team/<int:id>/',views.Team_detail,name='Team_detail'),