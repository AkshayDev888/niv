from nvi import views
from django.urls import path
app_name='nvi'

urlpatterns=[
    path('',views.Home,name='Home'),
    path('team/<int:id>/',views.Team_detail,name='Team_detail'),
    path('blog/<int:id>/',views.Blog_detail,name='Blog_detail'),

]