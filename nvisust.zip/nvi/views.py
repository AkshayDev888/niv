from django.shortcuts import render
from .models import Blog,Team,Project,Gallery

# Create your views here.
def Home(request):
    obj = Team.objects.all()
    project=Project.objects.all()
    blog = Blog.objects.all()
    gallery=Gallery.objects.all()
    return render(request,"index.html",{'obj':obj,'project':project,'blog':blog,'gallery':gallery})
def Team_detail(request,id):
    obj = Team.objects.get(id=id)

    return render(request, "team.html", {'obj': obj})


def Project_detail(request,id):
    project = Project.objects.get(id=id)

    return render(request, "project.html", {'project': project})
def Blog_detail(request,id):
    blog = Blog.objects.get(id=id)

    return render(request, "blog.html", {'blog': blog})
