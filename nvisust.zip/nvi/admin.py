from django.contrib import admin
from .models import Blog,Team,Gallery,Project
admin.site.register(Blog)
admin.site.register(Team)
admin.site.register(Gallery)
admin.site.register(Project)

# Register your models here.
